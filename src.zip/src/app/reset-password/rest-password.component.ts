import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rest-password',
  templateUrl: './rest-password.component.html'
})
export class RestPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
